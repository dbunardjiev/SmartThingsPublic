Images for Readme.md
